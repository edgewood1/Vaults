[[App-Pages Router]]


App 

root segments 
* required 
* Optional

Route segments
* static
* Dynamic


API routes

Other
- Route Groups (App Router): Organize routes without affecting the URL path (e.g., (marketing)/about/page.js is still accessed at /about). Useful for layout grouping and conditional layouts.
- Parallel Routes (App Router): Render multiple independent pages within a single layout (e.g., a dashboard with multiple sections). Uses @folderName convention.
- intercepted Routes (App Router): Load a route within the current layout, often used for modals or full-screen overlays. Uses (...)folderName convention.

Pages 

- Static Routes: Create pages that map directly to file names (e.g., `pages/about.js -> /about`).
- Dynamic Routes: Use square brackets ([]) for dynamic segments (e.g., `pages/blog/[slug].js` or `app/blog/[slug]/page.js`).
- Nested Routes: Create hierarchical routes by nesting folders.
- Catch-all Routes Use `[...slug].js` in pages router, or `[[...slug]]/page.js` in the app router to match any path.

Routing/rendering
- Link Component: Use next/link for client-side navigation, which provides prefetching and improves performance. Avoid using standard <a> tags for internal links.
pages


