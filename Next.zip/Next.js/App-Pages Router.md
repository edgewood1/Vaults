

Routes: dynamic, static, etc

**4. Middleware:**

- **Pages Router:** The recommended way to use middleware with Pages Router API routes is to use a library like `next-connect`. You wrap your handler function with the middleware.
    
    JavaScript
    
    ```
    // pages/api/protected.js
    import nc from 'next-connect';
    
    const handler = nc()
      .use(someMiddleware) // Apply middleware
      .get((req, res) => {
        res.json({ message: 'Protected resource' });
      });
    
    export default handler;
    ```
    
- **App Router:** Middleware is handled in a separate `middleware.js` (or `.ts`) file at the root of your `app` directory (or nested within subdirectories to apply to specific routes). This is a more integrated and declarative approach.
    
    JavaScript
    
    ```
    // app/middleware.js
    import { NextResponse } from 'next/server';
    
    export function middleware(request) {
      // Example: Redirect based on a condition
      if (request.nextUrl.pathname.startsWith('/admin') && !isAuthenticated(request)) {
        return NextResponse.redirect(new URL('/login', request.url));
      }
      return NextResponse.next(); // Continue processing
    }
    
    // Optionally, use config to match specific paths:
    export const config = {
      matcher: '/admin/:path*',
    };
    ```
    

**When to Use Which (Recommendation):**

- **App Router (Route Handlers) is the recommended approach for new projects.** It's more modern, uses web standards, has better middleware support, supports streaming, and integrates well with other App Router features (like Server Components).
    
- **Pages Router (`pages/api`) is still perfectly valid and supported.** If you have an existing project using the Pages Router, there's no urgent need to migrate _all_ your API routes. You can gradually adopt the App Router for new features. Migrating is generally straightforward, but you need to be mindful of the differences in request/response objects and middleware.
    
What if you have the same pages/app route?

If you have both `pages/api/users.js` and `app/api/users/route.js` in your Next.js project, and a client calls `/api/users`, the **App Router (`app/api/users/route.js`) will take precedence and handle the request.**

Here's the order of precedence Next.js uses when resolving routes, from highest to lowest:

1. **`app` Directory (App Router):** This is the _most important_ distinction. If a route exists in _both_ `app` and `pages`, the `app`route wins.
    
2. **`pages` Directory (Pages Router):** If a route _doesn't_ exist in the `app` directory, Next.js looks in the `pages` directory.
    
3. **Public Files:** Files in the `public` directory are served directly, but only if there's no matching route in `app` or `pages`.
    
4. **Rewrites (next.config.js):** Rewrites defined in `next.config.js` can modify the routing behavior, but they are applied _after_ the `app` and `pages` directories are checked.
    
5. **Redirects (next.config.js):** Redirects are processed after Rewrites.
    
6. **Headers (next.config.js):** Custom headers, if defined.
    
7. **`catch-all` routes:** if you had, say, `pages/api/[...all].js`, that would match anything _under_ `/api/` _only_ if no other route matched.
    

**Why the App Router Takes Precedence**

The App Router is the newer routing system in Next.js, and it's designed to be the primary routing mechanism. The developers intend for projects to transition to the App Router. Giving it precedence ensures that:

- **Gradual Adoption:** You can start using the App Router for new features without having to migrate all your existing Pages Router routes at once. New App Router routes will "override" older Pages Router routes with the same path.
- **Clear Intent:** If you've created a route in the `app` directory, it's likely that you _intend_ for that route to be used. It avoids accidental conflicts.
- **Future-Proofing:** Next.js is moving towards the App Router as the default. This precedence aligns with that direction.

**Important Considerations:**

- **Mixed Router Usage:** While you _can_ have both `pages` and `app` routers active simultaneously, it's generally recommended to be consistent within a given part of your application. For example, if you're building a new section of your site, use _only_ the App Router for that section. This keeps things predictable.
- **Migration:** If you're actively migrating from the Pages Router to the App Router, this precedence is helpful. You can create the App Router version of a route, test it, and then delete the Pages Router version when you're ready. The App Router route will immediately take over.
- **Debugging:** If you're seeing unexpected behavior, remember this precedence rule! It's a common source of confusion when working with both routers. Double-check your file structure. A helpful tool during development is to log something (e.g., `console.log("Pages Router handler")` or `console.log("App Router handler")`) in _both_your `pages/api` handler and your `app` route handler. This will immediately show you which one is being executed.
- **next.config.js:** While not directly impacting which router is selected, be mindful of any `rewrites` or `redirects` in your `next.config.js` file. These can alter the final destination of a request, even after the `app` or `pages` router has matched. It's always a good idea to check your configuration file if route resolution isn't behaving as expected.

In summary, the App Router always wins if a route is defined in both places. This behavior is intentional and supports a smooth transition to the newer routing system.