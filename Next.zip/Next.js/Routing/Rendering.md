
Pages Router:

- getStaticProps: Fetch data at build time for static generation (SSG). Ideal for content that doesn't change frequently.
- getServerSideProps: Fetch data on each request for server-side rendering (SSR). Use for dynamic content or data that requires authentication.
- getStaticPaths (with Dynamic Routes): Used with getStaticProps to specify which dynamic paths should be pre-rendered at build time.

[[App routes]]

Traditional
* user requests /start - server creates the page and serves it
* User requests /stop - “”
* User requests /stop/5 - “”

CSR - client side rendering
* Single index.html with an id
* User requests /start & http Request for JS, CSS, HTML
* Page built in the browser
* Navs handled by JS browser (History API)
* “Built on client during run-time”

SSR - server side rendering
- Built on server during build (pre-runtime)”

SSG - static generation
* Built on server before deploy? How does this differ from during build?

What is History API?


Generally
* SSR - request made in address bar and full page rendered
* CSR - request made in address bar, Navs intercept, request JS, HTML, CSS, build in client

OR at fidelity
* initial page request downloads JS block renderer
* Renders page on client or server.
* Block: JSON file
* JS iterates jSON file to build a set of forms for a page

Two kinds of JS loading 
* dynamic: async
* Static: blocking