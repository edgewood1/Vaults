[[Rendering]]

useRouter  Hook (Pages Router): Access route information (pathname, query parameters) and programmatically navigate (e.g., router.push('/about')).
- useParams and useSearchParams Hooks (App Router): Access route parameters and query parameters within components and layouts.
- redirect Function (App Router): Programmatically redirect users from within Server Components and Route Handlers (e.g., redirect('/login')).