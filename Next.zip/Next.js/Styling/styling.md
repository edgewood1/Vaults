- CSS Modules: Use .module.css files for locally scoped styles (e.g., styles/MyComponent.module.css). Import them directly into your components.
- Styled-JS: Write scoped CSS within your components using -style jsx- tags (built-in, but less commonly used now).
- Tailwind CSS: A popular utility-first CSS framework. Requires setup, but integrates well with Next.js.
- CSS-in-JS Libraries: Emotion, Styled Components, etc. (require configuration).
- UI Component Libraries: Material UI, Ant Design, Chakra UI, etc.
[[Optional]]

Global stylesGlobal Styles: Import a CSS file in pages/_app.js (Pages Router) or app/layout.js (App Router).