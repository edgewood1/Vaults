- Pages Router: Create API endpoints within the pages/api directory. Files map to API routes (e.g., pages/api/users.js -> /api/users).
- App Router: Create route.js (or .ts, .jsx, .tsx) files within the app directory to define Route Handlers. Use named exports for HTTP methods (e.g., export async function GET() {}).
- Request/Response: Understand how to handle different HTTP methods (GET, POST, PUT, DELETE, etc.), access request data (query parameters, body), and send responses (JSON, text, etc.).
- Database Integration: Connect to databases (e.g., Prisma, MongoDB, Supabase) from within your API routes (server-side only).


- **Pages Router (`pages/api`):**
    
    - `pages/api/users.js` creates an endpoint at `/api/users`.
    - `pages/api/users/[id].js` for `/api/users/:id`).

- **App Router (called Route Handlers):**
    
    - Route Handlers are defined in a special file named `route.js` _inside_ a folder that represents the route segment. 
    - The `route.js` file is _required_ within the folder.
    - app/api/users/route.js` creates an endpoint at `/api/users`.
    - (e.g., `app/api/users/[id]/route.js` for `/api/users/:id`).

API —— 

- **Pages Router:**
    
    - You export a _single_ default function (usually named `handler`).
    - This function receives two arguments: `req` (the incoming request object) and `res` (the response object). These are standard Node.js HTTP request and response objects, extended by Next.js.
    - You manually check the `req.method` to handle different HTTP methods (GET, POST, PUT, DELETE, etc.).
    
    JavaScript
    
    ```
    // pages/api/products.js
    export default async function handler(req, res) {
      if (req.method === 'GET') {
        // Handle GET request
      } else if (req.method === 'POST') {
        // Handle POST request
      } else {
        res.status(405).end(); // Method Not Allowed
      }
    }
    ```
    
- **App Router (Route Handlers):**
    
    - You export _named_ functions, one for each supported HTTP method. The function names are the uppercase HTTP method names (GET, POST, PUT, DELETE, PATCH, HEAD, OPTIONS).
    - These functions receive a `Request` object (which is the standard Web `Request` object, _not_ the Node.js `req`object) and a `context` object. The context contains parameters in `context.params`.
    - You return a `Response` object (also the standard Web `Response` object) or a `NextResponse` object (a helpful extension from Next.js).
    
    JavaScript
    
    ```
    // app/api/products/route.js
    import { NextResponse } from 'next/server';
    
    export async function GET(request, context) {
        //context.params contains the route parameters
      // Handle GET request
      return NextResponse.json({ message: 'Hello from GET' });
    }
    
    export async function POST(request) {
      // Handle POST request
      const data = await request.json(); // Use request.json() to parse JSON body
      return NextResponse.json({ message: 'Hello from POST', data });
    }
    
    // No default export needed!
    ```
    

**3. Request and Response Objects:**

- **Pages Router:** Uses Node.js's built-in `http.IncomingMessage` (for `req`) and `http.ServerResponse` (for `res`), extended by Next.js. These have methods like `req.query`, `req.body`, `res.status()`, `res.json()`, `res.send()`.
    
- **App Router:** Uses the standard Web Fetch API's]([https://www.google.com/search?q=https://developer.mozilla.org/en-US/docs/Web/API/Fetch_API)%27s](https://www.google.com/search?q=https://developer.mozilla.org/en-US/docs/Web/API/Fetch_API)%27s)) `Request` and `Response` objects. This is a more modern and standardized approach. You use methods like `request.json()`, `request.text()`, `request.formData()`, and create responses using `new Response()` or `NextResponse.json()`, `NextResponse.redirect()`, etc.
    

**5. Streaming:**

- **Pages Router:** Streaming is not directly supported.
- **App Router:** Supports streaming responses using the Web Streams API, making it possible to send data to the client incrementally.

**6. Edge Runtime:**

- **Pages Router:** By default, API routes run in a Node.js environment. You _can_ opt-in to the Edge Runtime using the `config` export, but it's not the default.
    
    JavaScript
    
    ```
    // pages/api/edge-function.js
    export const config = {
      runtime: 'edge',
    };
    
    export default async function handler(req, res) { ... }
    ```
    
- **App Router:** You can choose between the Node.js runtime and the Edge Runtime _per route_ using the `runtime`export. The Edge Runtime is often preferred for its performance benefits (lower latency, closer to the user), but it has limitations on available APIs.
    
    JavaScript
    
    ```
    // app/api/edge-route/route.js
    export const runtime = 'edge'; // or 'nodejs'
    
    export async function GET(request) { ... }
    ```
    ‘

**7. Data Fetching (Within the Route Handler):**

- **Pages Router:** You can use any method to fetch data (e.g., `fetch`, `axios`, database clients) within your handler function.
    
- **App Router:** You can _also_ use any method, but Next.js extends the `fetch` API to provide automatic request deduping and caching. This is a significant performance improvement, especially when multiple components on a page might need the same data.
    

**8. Mutability (POST, PUT, DELETE):**

- **Pages Router**: Typically you would use req.body to get the data
- **App Router:** `request.json()`, `request.text()`, `request.formData()` all are available to read the request.
Summary


|                  |                                          |                                                                   |
| ---------------- | ---------------------------------------- | ----------------------------------------------------------------- |
| **Feature**      | **Pages Router (pages/api)**             | **App Router (Route Handlers)**                                   |
| Directory        | `pages/api`                              | `app/.../route.js`                                                |
| Function Exports | Single default `handler` function        | Named functions per HTTP method (GET, POST, etc.)                 |
| Request Object   | Node.js `req` (extended)                 | Web `Request`                                                     |
| Response Object  | Node.js `res` (extended)                 | Web `Response` / `NextResponse`                                   |
| Middleware       | `next-connect` (or similar library)      | `middleware.js` file                                              |
| Streaming        | Not supported                            | Supported                                                         |
| Runtime          | Node.js (default), Edge (opt-in)         | Node.js or Edge (per-route)                                       |
| Recommendation   | For existing projects, gradual migration | **Recommended for new projects**                                  |
| HTTP methods     | if/else checking of `req.method`         | Individual functions per method. `export async function GET() {}` |
| Mutability       | `req.body`                               | `request.json()`, `request.text()`, `request.formData()`          |
| Parameters       | `req.query`                              | `context.params`                                                  |

