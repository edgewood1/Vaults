* another object that is used as a fallback source of properties
* If object does not have a property, it refers to its prototype, which can refer to its prototype, etc
* Empty objects have Object as their prototype: Object.prototype