Constructurs are functions that are called with the “new” keyword
How to create an object that derives from some shared prototype? 

```mermaid  
flowchart LR
 A --- B
 C --> D
 F <--> E
```
