Example: Redis

- will return data if in its store
- This way, DB doesn’t need to be accessed

Direction: 
[[DB]]